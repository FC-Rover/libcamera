.. SPDX-License-Identifier: CC-BY-SA-4.0

.. TODO: Write an overview of libtuning

Dependencies
------------

- cv2
- numpy
- pyexiv2
- rawpy
